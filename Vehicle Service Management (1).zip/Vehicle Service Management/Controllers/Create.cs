﻿using Microsoft.AspNetCore.Mvc;
using Repositories;
using ApplicationServices;
using Domain;
using Microsoft.AspNetCore.Authorization;

namespace Vehicle_Service_Management.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class Create: ControllerBase
    {
        private readonly IApiServices _apiService;
        public Create(IApiServices apiService)
        {
            _apiService = apiService;
        }
        [HttpPost]
        [ActionName("CreateTable")]
        [Authorize]
        public string CreateTable(Query query)
        {
            return _apiService.CreateTable(query);
        }

        [HttpPost]
        [ActionName("CreateVehicleTable")]
        [Authorize]
        public string CreateVehicelTable()
        {
            Query query = new Query() { 
                TableName="Vehicle",
                Attributes=new List<string>()
                {
                    "int,service_center_id",
                    "text primary key,vin",
                    "text,model",
                    "date,date",
                    "text,status",
                    "FOREIGN KEY (service_center_id) REFERENCES ServiceCenter(ID), "
                }
            };
            return _apiService.CreateTable(query);
        }

        [HttpPost]
        [ActionName("CreateServiceCenterTable")]
        [Authorize]
        public string CreateServiceCentreTable()
        {
            Query query = new Query()
            {
                TableName = "ServiceCenter",
                Attributes = new List<string>()
                {
                    "int primary key,ID",
                    "text,name"
                }
            };
            return _apiService.CreateTable(query);
        }

        
    }
}
