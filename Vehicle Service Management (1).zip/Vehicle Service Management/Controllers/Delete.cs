﻿using ApplicationServices;
using Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Vehicle_Service_Management.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class Delete : ControllerBase
    {
        private readonly IApiServices _apiServices;

        public Delete(ILogger<Delete> logger, IApiServices apiServices)
        {
            _apiServices = apiServices;
        }

        [HttpDelete]
        [ActionName("DeleteRecord")]
        [Authorize]
        public string DeleteRecord(Query query)
        {
            return _apiServices.DeleteRecord(query);
        }

        [HttpDelete]
        [ActionName("DeleteVehicleByVIN")]
        [Authorize]
        public string DeleteVehicleByVIN(string VIN)
        {
            return _apiServices.DeleteVehicleByVIN(VIN);
        }

        [HttpDelete]
        [ActionName("DeleteVehiclesByServiceCenterID")]
        [Authorize]
        public string DeleteVehiclesByServiceCenterID(int id)
        {
            return _apiServices.DeleteVehiclesByServiceCenterID(id);
        }

        [HttpDelete]
        [ActionName("DeleteVehiclesByServiceCenterName")]
        [Authorize]
        public string DeleteVehiclesByServiceCenterName(string name)
        {
            return _apiServices.DeleteVehiclesByServiceCenterName(name);
        }

        [HttpDelete]
        [ActionName("DeleteServiceCenterByID")]
        [Authorize]
        public string DeleteServiceCenterByID(int id)
        {
            return _apiServices.DeleteServiceCenterByID(id);
        }

        [HttpDelete]
        [ActionName("DeleteServiceCenterByName")]
        [Authorize]
        public string DeleteServiceCenterByName(string name)
        {
            return _apiServices.DeleteServiceCenterByName(name);
        }

        [HttpDelete]
        [ActionName("DeleteUser")]
        [Authorize]
        public string DelteUser(string userName, string password)
        {
            Query query = new Query
            {
                TableName = "UserDetails",
                Conditions = new List<string>()
            };
            query.Conditions.Add($"username='{userName}'");
            query.Conditions.Add($"password='{password}'");
            return _apiServices.DeleteRecord(query);

        }

    }
}
