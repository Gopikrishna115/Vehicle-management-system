using ApplicationServices;
using DataBase;
using Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace Vehicle_Service_Management.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class Get : ControllerBase
    {
        private readonly IApiServices _apiServices;

        public Get(IApiServices apiServices)
        {
            _apiServices = apiServices;
        }

        [HttpGet]
        [ActionName("GetRecords")]
        [Authorize]
        public List<dynamic> GetRecords(Query query)
        {
            List<dynamic> records = _apiServices.GetRecords(query);
            return records;
        }

        [HttpGet]
        [ActionName("GetVehicles")]
        [Authorize]
        public List<Vehicle> GetVehicles()
        {
            Query query = new Query()
            {
                TableName = "Vehicle"
            };
            return _apiServices.GetVehicles(query);
        }

        [HttpGet]
        [ActionName("GetVehicleByVIN")]
        [Authorize]
        public Vehicle GetVehicleByVIN(string VIN)
        {
            return _apiServices.GetVehicleByVIN(VIN);
        }

        [HttpGet]
        [ActionName("GetVehicleByServiceCenterID")]
        [Authorize]
        public List<Vehicle> GetVehiclesByServiceCenterID(int id)
        {
            return _apiServices.GetVehiclesByServiceCenterID(id);
        }

        [HttpGet]
        [ActionName("GetVehiclesByServiceCenterName")]
        [Authorize]
        public List<Vehicle> GetVehiclesByServiceCenterName(string name)
        {
            return _apiServices.GetVehiclesByServiceCenterName(name);
        }

        [HttpGet]
        [ActionName("GetServiceCenters")]
        [Authorize]
        public List<ServiceCenter> GetServiceCenters()
        {
            return _apiServices.GetServiceCenters();
        }

        [HttpGet]
        [ActionName("GetServiceCenterByName")]
        [Authorize]
        public ServiceCenter GetServiceCenterByName(string name)
        {
            return _apiServices.GetServiceCenterByName(name);
        }

        [HttpGet]
        [ActionName("GetServiceCenterByID")]
        [Authorize]
        public ServiceCenter GetServiceCenterByID(int id)
        {
            return _apiServices.GetServiceCenterByID(id);
        }

        [HttpGet]
        [ActionName("GetServiceCenterByVIN")]
        [Authorize]
        public ServiceCenter GetServiceCenterByVIN(string vin)
        {
            return _apiServices.GetServiceCenterByVIN(vin);
        }

        [HttpGet]
        [ActionName("GroupVehicleByServiceCenter")]
        [Authorize]
        public Dictionary<string, List<Vehicle>> GroupVehicleByServiceCenter()
        {
            return _apiServices.GroupVehicleByServiceCenter();
        }

        [HttpGet]
        [ActionName("GroupVehiclesByStatus")]
        [Authorize]
        public Dictionary<string, List<Vehicle>> GroupVehiclesByStatus()
        {
            return _apiServices.GroupVehiclesByStatus();
        }

        [HttpGet]
        [ActionName("GroupVehicleByServiceCenterOnDate")]
        [Authorize]
        public Dictionary<string,List<Vehicle>> GroupVehicleByServiceCenterOnDate(DateOnly date)
        {
            return _apiServices.GroupVehicleByServiceCenterOnDate(date);
        }

        [HttpGet]
        [ActionName("ValidateUser")]
        public dynamic ValidateUser(string username, string password)
        {

            if(_apiServices.ValidateUser(username, password))
            {
                string token= _apiServices.GenerateToken(new UserDetails { userName = username, password = password });
                return new { status=true, token=token };
            }
            return new { status = false, token = "Unauthorized" };

        }

        [HttpGet]
        [ActionName("GetUserRole")]
        [Authorize]
        public int GetUserRole(string username, string password)
        {
            return this._apiServices.GetUserRole(username, password);
        }

        [HttpGet]
        [ActionName("GetUsernames")]  
        public List<string> GetUsernames()
        {
            return this._apiServices.GetUsernames();
        }
    }
}