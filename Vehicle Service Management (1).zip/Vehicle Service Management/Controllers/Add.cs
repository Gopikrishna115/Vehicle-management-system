﻿using ApplicationServices;
using Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Vehicle_Service_Management.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class Add : ControllerBase
    {
        private readonly ILogger<Add> _logger;
        private readonly IApiServices _apiServices;

        public Add(ILogger<Add> logger, IApiServices apiServices)
        {
            _logger = logger;
            _apiServices = apiServices;
        }

        [HttpPost]
        [ActionName("AddRecord")]
        [Authorize]
        public string AddRecord(Query query)
        {
            return _apiServices.AddRecord(query);
        }

        [HttpPost]
        [ActionName("AddVehicle")]
        [Authorize]
        public string AddVehicle(Vehicle vehicle)
        {
            List<string> values = new List<string>() {
                $"service_center_id={vehicle.service_center_id}"
                ,$"vin='{vehicle.VIN}'"
                ,$"model='{vehicle.Model}'"
                ,$"date='{vehicle.Date.ToString("yyyy-MM-dd")}'"
                ,$"status='{vehicle.Status}'"
            };
            Query query = new Query
            {
                TableName = "Vehicle",
                Values = new List<List<string>>()
            };
            query.Values.Add(values);
            return _apiServices.AddRecord(query);
        }

        [HttpPost]
        [ActionName("AddVehicles")]
        [Authorize]
        public string AddVehicles(List<Vehicle> vehicles)
        {
            List<List<string>> values = new List<List<string>>();
            
                foreach(Vehicle vehicle in vehicles)
                {
                    values.Add(new List<string>()
                    {
                        $"service_center_id={vehicle.service_center_id}"
                        ,$"vin='{vehicle.VIN}'"
                        ,$"model='{vehicle.Model}'"
                        ,$"date='{vehicle.Date.ToString("yyyy-MM-dd")}'"
                        ,$"status='{vehicle.Status}'"
                    });
                
                }
            Query query = new Query
            {
                TableName = "Vehicle",
                Values = new List<List<string>>()
            };
            query.Values=values;
            return _apiServices.AddRecord(query);
        }

        [HttpPost]
        [ActionName("AddServiceCenter")]
        [Authorize]
        public string AddServiceCenter(ServiceCenter serviceCenter)
        {
            Query query = new Query
            {
                TableName = "ServiceCenter",
                Values = new List<List<string>>()
            };
            query.Values.Add(new List<string>()
            {
                $"id={serviceCenter.ID}",
                $"name='{serviceCenter.Name}'"
            });
            return _apiServices.AddRecord(query);
        }

        [HttpPost]
        [ActionName("AddUser")]
        [Authorize]
        public string AddUser(UserDetails user)
        {
            Query query = new Query
            {
                TableName = "UserDetails",
                Values = new List<List<string>>()
            };
            query.Values.Add(new List<string>()
            {
                $"username='{user.userName}'",
                $"password='{user.password}'",
                $"role={user.role}"
            });
            return _apiServices.AddRecord(query);

        }



    }
}
