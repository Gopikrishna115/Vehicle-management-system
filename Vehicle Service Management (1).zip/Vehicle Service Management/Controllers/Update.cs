﻿using ApplicationServices;
using Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Vehicle_Service_Management.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class Update : ControllerBase
    {
        private readonly IApiServices _apiServices;

        public Update(IApiServices apiServices)
        {
            _apiServices = apiServices;
        }

        [HttpPut]
        [ActionName("UpdateRecord")]
        [Authorize]
        public string UpdateRecord(Query query)
        {
            return _apiServices.UpdateRecord(query);
        }

        [HttpPut]
        [ActionName("UpdateVehicle")]
        [Authorize]
        public string UpdateVehicle(Query query)
        {
            return _apiServices.UpdateVehicle(query);
        }

        [HttpPut]
        [ActionName("UpdateServiceCenter")]
        [Authorize]
        public string UpdateServiceCenter(Query query)
        {
            return _apiServices.UpdateServiceCenter(query);
        }

        [HttpPut]
        [ActionName("UpdateVehicleByVIN")]
        [Authorize]
        public string UpdateVehicleByVIN(string VIN, Vehicle vehicle)
        {
            return _apiServices.UpdateVehicleByVIN(VIN, vehicle);
        }

        [HttpPut]
        [ActionName("UpdateServiceCenterByID")]
        [Authorize]
        public string UpdateServiceCenterByID(int id, ServiceCenter serviceCenter)
        {
            Query query = new Query()
            {
                TableName = "ServiceCenter",
                Values = new List<List<string>>()
                {
                    new List<string>(){ 
                        $"name='{serviceCenter.Name}'" 
                    }
                },
                Conditions = new List<string>
                {
                    $"id={id}"
                }
            };
            return _apiServices.UpdateServiceCenterByID(id, query);
        }

        [HttpPut]
        [ActionName("UpdateUser")]
        [Authorize]
        public string UpdateUser(string userName, string password,UserDetails user)
        {
            Query query = new Query
            {
                TableName = "UserDetails",
                Conditions = new List<string>(),
                Values = new List<List<string>>()
            };
            query.Values.Add(new List<string>()
            {
                $"username='{user.userName}'",
                $"password='{user.password}'",
                $"role={user.role}"
            });
            query.Conditions.Add($"username='{userName}'");
            query.Conditions.Add($"password='{password}'");
            return _apiServices.UpdateRecord(query);

        }
    }
}
